/* !!! Uwaga !!! */
/* Ta konfiguracja zależy od kilku dodatkowych bibliotek. Zainstaluj je za pomocą menedżera bibliotek:  */
/* Adafruit GFX Library */



#ifndef myoptions_h
#define myoptions_h

#define L10N_LANGUAGE           RU    

//#define LED_BUILTIN_S3    48   /* S3-onboard RGB led pin */
#define USE_BUILTIN_LED   false    /* Use S3-onboard RGB led */

/* ArduinoOTA Support */
#define USE_OTA true                    /* Enable OTA updates from Arduino IDE */
#define OTA_PASS "myotapassword12345"   /* OTA password for secure updates */

/* HTTP Authentication */
//#define HTTP_USER "admin"               /* HTTP basic authentication username */
//#define HTTP_PASS "andrew123"           /* HTTP basic authentication password */

#define DSP_MODEL           DSP_ILI9488
#define TFT_CS              10              
#define TFT_MOSI            11              
#define TFT_SCLK            12              
#define TFT_MISO            13              
//#define BRIGHTNESS_PIN    5               
#define TFT_DC              7
#define TFT_RST             -1 

#define I2S_DOUT          9             
#define I2S_BCLK          3             
#define I2S_LRC           1             

#define ENC2_BTNL        38  //  CLK   
#define ENC2_BTNR        14  //  DT    
#define ENC2_BTNB        15  //  SW
#define ENC2_INTERNALPULLUP     false   

#define IR_PIN            4 

/* RTC DS3231 Module - DISABLED FOR NOW */
//#define RTC_MODULE        DS3231        /* DS3231 or DS1307 */
//#define RTC_SDA           17            /* I2C SDA pin for RTC */ 
//#define RTC_SCL           18            /* I2C SCL pin for RTC */ 

/*  SDCARD  */
//  #define SDC_CS          39      /* SDCARD CS pin */
// Connect SDC_MOSI to  40  /* On board can be D1 pin */
// Connect SDC_SCK to   41   /* On board can be CLK pin */
// Connect SDC_MISO to  42  /* On board can be D0 pin */
//  #define SD_SPIPINS  41, 42, 40    /* SCK, MISO, MOSI */

/* Ustawiena Fontu Zegara */
#define CLOCKFONT_MONO false    /* false = używamy fontu Arimo dla ILI9488 */

/* Imieniny */
#define NAMEDAY_ENABLED true   /* true = wyświetlaj imieniny, false = wyłączone */

/* Ustawiena Zegara TTS Google */
#define CLOCK_TTS_ENABLED  1                            // 1 = włączone, 0 = wyłączone
#define CLOCK_TTS_LANGUAGE "pl"                         // Domyślny język TTS (np. pl,en,de,ru,fr,hu)
#define CLOCK_TTS_INTERVAL_MINUTES 30                   // Domyślny interwał ogłaszania (w minutach, np. 1, 5, 15, 30, 60)




#endif
