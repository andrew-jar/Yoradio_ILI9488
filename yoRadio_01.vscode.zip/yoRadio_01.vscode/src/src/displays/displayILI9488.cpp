#include "../core/options.h"
#if DSP_MODEL==DSP_ILI9488 || DSP_MODEL==DSP_ILI9486

#include "displayILI9488.h"
//#include <SPI.h>
#include "fonts/bootlogo.h"
#include "../core/config.h"
#include "../core/network.h"
#include "../core/namedays.h"

#ifndef DEF_SPI_FREQ
  #define DEF_SPI_FREQ        40000000UL      /*  set it to 0 for system default */
#endif

#if DSP_HSPI
  DspCore::DspCore(): ILI9486_SPI(&SPI2, TFT_CS, TFT_DC, TFT_RST) {}
#else
  DspCore::DspCore(): ILI9486_SPI(TFT_CS, TFT_DC, TFT_RST) {}
#endif

#include "tools/utf8RusGFX.h"

void DspCore::initDisplay() {
  setSpiKludge(false);
  init();
  //if(DEF_SPI_FREQ > 0) setSPISpeed(DEF_SPI_FREQ);
  cp437(true);
  setTextWrap(false);
  setTextSize(1);
  fillScreen(0x0000);
  invert();
  flip();
  
  plItemHeight = playlistConf.widget.textsize*(CHARHEIGHT-1)+playlistConf.widget.textsize*4;
  plTtemsCount = round((float)height()/plItemHeight);
  if(plTtemsCount%2==0) plTtemsCount++;
  plCurrentPos = plTtemsCount/2;
  plYStart = (height() / 2 - plItemHeight / 2) - plItemHeight * (plTtemsCount - 1) / 2 + playlistConf.widget.textsize*2;
}

void DspCore::drawLogo(uint16_t top) { drawRGBBitmap((width() - 460) / 2, (height() - 260) / 4, bootlogo2, 460, 260); }


void DspCore::printPLitem(uint8_t pos, const char* item, ScrollWidget& current){
  setTextSize(playlistConf.widget.textsize);
  if (pos == plCurrentPos) {
    current.setText(item);
  } else {
    uint8_t plColor = (abs(pos - plCurrentPos)-1)>4?4:abs(pos - plCurrentPos)-1;
    setTextColor(config.theme.playlist[plColor], config.theme.background);
    setCursor(TFT_FRAMEWDT, plYStart + pos * plItemHeight);
    fillRect(0, plYStart + pos * plItemHeight - 1, width(), plItemHeight - 2, config.theme.background);
    print(utf8Rus(item, true));
  }
}

void DspCore::drawPlaylist(uint16_t currentItem) {
  uint8_t lastPos = config.fillPlMenu(currentItem - plCurrentPos, plTtemsCount);
  if(lastPos<plTtemsCount){
    fillRect(0, lastPos*plItemHeight+plYStart, width(), height()/2, config.theme.background);
  }
}

void DspCore::clearDsp(bool black) { fillScreen(black?0:config.theme.background); }

GFXglyph *pgm_read_glyph_ptr(const GFXfont *gfxFont, uint8_t c) {
  return gfxFont->glyph + c;
}

uint8_t DspCore::_charWidth(unsigned char c){
  GFXglyph *glyph = pgm_read_glyph_ptr(&Arimo_Regular_72, c - 0x20);
  return pgm_read_byte(&glyph->xAdvance);
}

uint16_t DspCore::textWidth(const char *txt){
  uint16_t w = 0, l=strlen(txt);
  for(uint16_t c=0;c<l;c++) w+=_charWidth(txt[c]);
  return w;
}

void DspCore::_getTimeBounds() {
  // Tworzymy bufor tylko z godzinami do pomiaru szerokości
  char hourBuf[4];
  strftime(hourBuf, sizeof(hourBuf), "%H", &network.timeinfo);
  _dotsLeft = textWidth(hourBuf);
  
  // Szerokość całego czasu (godziny + dwukropek + minuty)
  char fullTimeBuf[8];
  strftime(fullTimeBuf, sizeof(fullTimeBuf), "%H:%M", &network.timeinfo);
  _timewidth = textWidth(fullTimeBuf);
}



void DspCore::_clockSeconds(){
  // Wyczyść mniejszy obszar sekund - tylko wysokość potrzebną dla cyfr
  dsp.fillRect(400, clockTop-clockTimeHeight+35, 80, 35, config.theme.background);
  
  // Użyj mniejszego fontu Arimo dla sekund (36px vs 72px dla głównego zegara)
  setFont(&Arimo_Regular_36); 
  setTextSize(1);
  setTextColor(config.theme.seconds, config.theme.background);
  setCursor(410, clockTop-clockTimeHeight+60); // Opuszczone o 20 pikseli w dół
  sprintf(_bufforseconds, "%02d", network.timeinfo.tm_sec);
  if(!config.isScreensaver) print(_bufforseconds);              /* print seconds */
  
  // Rysowanie mrugającego dwukropka
  setTextSize(1);
  setFont(&Arimo_Regular_72);
  setTextColor((network.timeinfo.tm_sec % 2 == 0) ? config.theme.clock : config.theme.background, config.theme.background);
  // Pozycja dwukropka: dokładnie po 2 cyfrach godzin (2*41=82 pikseli)
  int colonPosition = _timeleft + 82;
  setCursor(colonPosition, clockTop-8);
  print(":");                                     /* print dots */
  setFont();
}

void DspCore::_clockDate(){
  // Wyczyść poprzednią datę
  if(_olddateleft>0)
    dsp.fillRect(_olddateleft,  clockTop+14, _olddatewidth, CHARHEIGHT*2, config.theme.background);
  
  // Wyczyść poprzednie imieniny - użyj max szerokości żeby usunąć wszystkie stare znaki
  #if NAMEDAY_ENABLED
  if(_oldnamedayleft>0) {
    int clearWidth = max(_oldnamedaywidth, _namedaywidth) + 20; // dodaj trochę buforu
    dsp.fillRect(_oldnamedayleft, clockTop+14, clearWidth, CHARHEIGHT*2, config.theme.background);
  }
  #else
  // Wyczyść obszar imienin gdy są wyłączone
  if(_oldnamedayleft>0 && _oldnamedaywidth>0) {
    dsp.fillRect(_oldnamedayleft, clockTop-5, _oldnamedaywidth + 100, CHARHEIGHT*3, config.theme.background);
  }
  #endif
  
  // Rysuj datę (zwykły kolor)
  setTextColor(config.theme.date, config.theme.background);
  setCursor(_dateleft, clockTop+15);
  setTextSize(2);
  if(!config.isScreensaver) print(_dateBuf);

  // Rysuj imieniny tylko jeśli włączone
  #if NAMEDAY_ENABLED
  // Rysuj "Imieniny:" w białym kolorze (górna linia) - mniejszy rozmiar
  setTextColor(config.theme.date, config.theme.background);
  setCursor(_namedayleft, clockTop-5); // przesunięte wyżej z clockTop-5, -69
  setTextSize(1);
  if(!config.isScreensaver) print("IMIENINY:");
  
  // Rysuj same imiona w złocistym kolorze 
  setTextColor(config.theme.nameday, config.theme.background);
  setCursor(_namedayleft, clockTop+15); // przesunięte wyżej z clockTop+15, -49
  setTextSize(2);
  if(!config.isScreensaver) print(_namedayBuf);
  #endif
  
  // Zapisz poprzednie wartości
  strlcpy(_oldDateBuf, _dateBuf, sizeof(_dateBuf));
  strlcpy(_oldNamedayBuf, _namedayBuf, sizeof(_namedayBuf));
  _olddatewidth = _datewidth;
  _olddateleft = _dateleft;
  _oldnamedaywidth = _namedaywidth;
  _oldnamedayleft = _namedayleft;
}

void DspCore::_clockTime(){
  // Wyczyść poprzedni czas (tylko jeśli się zmienił)
  if(_oldtimeleft>0) dsp.fillRect(_oldtimeleft, clockTop-clockTimeHeight+1-8, _oldtimewidth, clockTimeHeight, config.theme.background);
  // Pozycja zegara - przesunięta o 2mm w lewo (8 pikseli)
  _timeleft = 212; // Przesunięte z 220 na 212 (o około 8 pikseli w lewo)
  setTextSize(1);  //1
  setFont(&Arimo_Regular_72);
  
  setTextColor(config.theme.clock, config.theme.background);
  
  // Wyświetl tylko godziny
  char hourBuf[4], minuteBuf[4];
  strftime(hourBuf, sizeof(hourBuf), "%H", &network.timeinfo);
  strftime(minuteBuf, sizeof(minuteBuf), "%M", &network.timeinfo);
  
  setCursor(_timeleft, clockTop-8);
  print(hourBuf);  // Wyświetl godziny
  
  // Pozycja minut - stała pozycja po dwukropku (godziny zajmują 2*41=82 pikseli + dwukropek 21 pikseli)
  int minutePosition = _timeleft + 82 + 21; // 2 cyfry godzin + dwukropek
  setCursor(minutePosition, clockTop-8);
  print(minuteBuf);  // Wyświetl minuty
  setFont();
  strlcpy(_oldTimeBuf, _timeBuf, sizeof(_timeBuf));
  _oldtimewidth = 300; // Większa szerokość czyszczenia dla pewności
  _oldtimeleft = _timeleft;
  // Usunięto rysowanie linii oddzielających (poziomej i pionowej)

  // Format daty z imieninami: MAREK      NIEDZIELA - 06.07.2025
  char dowBuf[16];
  strncpy_P(dowBuf, (PGM_P)pgm_read_ptr(&(dowf[network.timeinfo.tm_wday])), sizeof(dowBuf));
  dowBuf[sizeof(dowBuf)-1] = '\0';
  for (int i = 0; dowBuf[i]; i++) {
    dowBuf[i] = toupper((unsigned char)dowBuf[i]);
  }
  char monthName[16];
  strncpy_P(monthName, (PGM_P)pgm_read_ptr(&(mnths[network.timeinfo.tm_mon])), sizeof(monthName));
  monthName[sizeof(monthName)-1] = '\0';
  for (int i = 0; monthName[i]; i++) {
    monthName[i] = toupper((unsigned char)monthName[i]);
  }
  
  // Pobierz imieniny na dzisiejszy dzień - tylko jeśli włączone
  #if NAMEDAY_ENABLED
  const char* nameday = getNameDay(network.timeinfo.tm_mon + 1, network.timeinfo.tm_mday);
  char namedayUpper[20];
  strlcpy(namedayUpper, nameday, sizeof(namedayUpper));
  for (int i = 0; namedayUpper[i]; i++) {
    namedayUpper[i] = toupper((unsigned char)namedayUpper[i]);
  }
  #endif
  
  snprintf(_buffordate, sizeof(_buffordate), "%s - %02d.%s.%04d", 
           dowBuf, network.timeinfo.tm_mday, monthName, network.timeinfo.tm_year+1900);
  strlcpy(_dateBuf, utf8Rus(_buffordate, true), sizeof(_dateBuf));
  _datewidth = strlen(_dateBuf) * CHARWIDTH*2;
  _dateleft = width() - 10 - clockRightSpace - _datewidth;
  
  // Imieniny - same imiona bez prefiksu w osobnym buforze
  #if NAMEDAY_ENABLED
  strlcpy(_namedayBuf, utf8Rus(namedayUpper, true), sizeof(_namedayBuf));
  _namedaywidth = strlen(_namedayBuf) * CHARWIDTH*2;
  #else
  _namedayBuf[0] = '\0';  // wyczyść bufor imienin
  _namedaywidth = 0;
  #endif
  _namedayleft = 24; // ta sama pozycja co ikona bitrate
}


  
void DspCore::printClock(uint16_t top, uint16_t rightspace, uint16_t timeheight, bool redraw){
  clockTop = top;
  clockRightSpace = rightspace;
  clockTimeHeight = timeheight;
  strftime(_timeBuf, sizeof(_timeBuf), "%H:%M", &network.timeinfo);
  
  // Pobierz aktualne imię (może się zmieniać co 4 sekundy) - tylko jeśli włączone
  #if NAMEDAY_ENABLED
  const char* currentNameday = getNameDay(network.timeinfo.tm_mon + 1, network.timeinfo.tm_mday);
  char currentNamedayBuf[50];
  strlcpy(currentNamedayBuf, utf8Rus(currentNameday, true), sizeof(currentNamedayBuf));
  #else
  char currentNamedayBuf[50] = "";  // pusty bufor gdy imieniny wyłączone
  #endif
  
  if(strcmp(_oldTimeBuf, _timeBuf)!=0 || redraw){
    _getTimeBounds();
    _clockTime();
    if(!config.isScreensaver) {
      if(strcmp(_oldDateBuf, _dateBuf)!=0 || strcmp(_oldNamedayBuf, currentNamedayBuf)!=0 || redraw) _clockDate();
    }
  }
  
  // Sprawdź czy imię się zmieniło (rotacja co 4 sekundy) - tylko jeśli włączone
  #if NAMEDAY_ENABLED
  if(!config.isScreensaver && strcmp(_oldNamedayBuf, currentNamedayBuf)!=0) {
    // Aktualizuj tylko imieniny bez przeładowywania całej daty
    strlcpy(_namedayBuf, currentNamedayBuf, sizeof(_namedayBuf));
    _namedaywidth = strlen(_namedayBuf) * CHARWIDTH*2; // aktualizuj szerokość
    _clockDate();
  }
  #endif
  
  _clockSeconds();
}

void DspCore::clearClock(){   //---------wielkosc czcionki 
  dsp.fillRect(_timeleft,  clockTop-clockTimeHeight-8, textWidth("88:88")+CHARWIDTH*3*2+24, clockTimeHeight+12+CHARHEIGHT, config.theme.background);
}

void DspCore::startWrite(void) {
  ILI9486_SPI::startWrite();
}

void DspCore::endWrite(void) { 
  ILI9486_SPI::endWrite();
}
  
void DspCore::loop(bool force) {

}

void DspCore::charSize(uint8_t textsize, uint8_t& width, uint16_t& height){
  width = textsize * CHARWIDTH;
  height = textsize * CHARHEIGHT;
}

void DspCore::setTextSize(uint8_t s){
  Adafruit_GFX::setTextSize(s);
}

void DspCore::flip(){
  setRotation(config.store.flipscreen?3:1);
}

void DspCore::invert(){
  invertDisplay(config.store.invertdisplay);
}

void DspCore::sleep(void) { 
  sendCommand(ILI9488_SLPIN); delay(150); sendCommand(ILI9488_DISPOFF); delay(150);
}

void DspCore::wake(void) { 
  sendCommand(ILI9488_DISPON); delay(150); sendCommand(ILI9488_SLPOUT); delay(150);
}

void DspCore::writePixel(int16_t x, int16_t y, uint16_t color) {
  if(_clipping){
    if ((x < _cliparea.left) || (x > _cliparea.left+_cliparea.width) || (y < _cliparea.top) || (y > _cliparea.top + _cliparea.height)) return;
  }
  ILI9486_SPI::drawPixel(x, y, color);
}

void DspCore::writeFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
  if(_clipping){
    if ((x < _cliparea.left) || (x >= _cliparea.left+_cliparea.width) || (y < _cliparea.top) || (y > _cliparea.top + _cliparea.height))  return;
  }
  ILI9486_SPI::writeFillRect(x, y, w, h, color);
}

void DspCore::setClipping(clipArea ca){
  _cliparea = ca;
  _clipping = true;
}

void DspCore::clearClipping(){
  _clipping = false;
}

void DspCore::setNumFont(){
  setFont(&Arimo_Regular_72);
  setTextSize(1);
}
#endif
