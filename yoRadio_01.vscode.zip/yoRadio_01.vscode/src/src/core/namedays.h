#ifndef namedays_h
#define namedays_h

#include "options.h"

#if NAMEDAY_ENABLED

#include <Arduino.h>

// Tablica imienin - imiona oddzielone przecinkami na każdy dzień roku (rotacja co 4 sekundy) - źródło: kalbi.pl
extern const char* namedays[] PROGMEM;

// Zmienne do rotacji imienin
extern uint32_t namedayLastRotation;   // czas ostatniej rotacji
extern uint8_t namedayCurrentIndex;    // aktualny indeks imienia
extern char currentNamedayBuffer[30];  // bufor na aktualne imię
extern int lastNamedayDay;             // ostatni dzień dla resetowania rotacji
extern int lastNamedayMonth;           // ostatni miesiąc dla resetowania rotacji

// Funkcja zwracająca aktualne imię na dany dzień roku z rotacją co 4 sekundy
const char* getNameDay(int month, int day);

#endif // NAMEDAY_ENABLED

#endif // namedays_h
